# AI Case Files

An interactive AI Fundamentals book with eight course chapters. Built with React, Vite, Tailwind CSS and Framer Motion.

## Publish with GitHub Pages

1. Create a public GitHub repository and put the contents of this folder at its root. Include `.github/workflows/pages.yml`.
2. Use the `main` branch.
3. Open Settings > Pages > Build and deployment. Select GitHub Actions as the source.
4. Push a commit or run Publish AI Case Files from Actions.
5. Open the deployment URL returned by the successful workflow.

The project automatically sets its asset path from the GitHub repository name. Chapter links remain within the project path. A normal project URL is https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/.

## Local development

Use Node.js 22 or later. Run `npm ci`, then `npm run dev`. Use `npm run build` for a production build and `npm run preview` to preview it.

Python examples are displayed as learning material. The website controls use JavaScript and do not execute Python or train models.
