import { BookIntroduction } from './components/CourseNotes';
import { useState } from 'react';
import { AnimatePresence, motion, MotionConfig, useReducedMotion, useScroll, useSpring } from 'framer-motion';
import { ArrowDown, ArrowRight, ArrowUpRight, BookOpen, Check, ChevronRight, CircleHelp, Eye, GitBranch, MoveRight, RotateCcw, Scale, ShieldCheck, SlidersHorizontal, Target, Wind } from 'lucide-react';
import CaseSelector from './components/CaseSelector';

const environments = [
  { title: 'Observability', options: 'Fully / partially / unobservable', detail: 'Can the agent see the information it needs? A chess agent can see the board. A self-driving system sees only what its sensors show.', icon: Eye },
  { title: 'Other agents', options: 'Single / multi-agent', detail: 'Does the agent act alone, or do other agents affect what happens? Chess has an active opponent.', icon: GitBranch },
  { title: 'Uncertainty', options: 'Deterministic / stochastic / strategic', detail: 'Does an action always have the same result, can chance change it, or can another agent change it?', icon: CircleHelp },
  { title: 'Structure', options: 'Episodic / sequential', detail: 'Are decisions mostly separate, or can an earlier choice change what the agent can do next? Pac-Man is sequential.', icon: RotateCcw },
  { title: 'Timing', options: 'Static / dynamic', detail: 'Can the world change while the agent is deciding? Pac-Man and self-driving situations can change over time.', icon: Wind },
  { title: 'Action space', options: 'Discrete / continuous / hybrid', detail: 'Can the agent choose from separate actions, adjust a value, or use both kinds? Chess moves are discrete; steering is continuous.', icon: SlidersHorizontal },
];
const architectures = [
  { name: 'Simple reflex', key: 'reflex', short: 'Act on what is seen now.', detail: 'It uses a rule such as “if the temperature is below 20, turn the heater on.” It is quick and easy to explain, but it may not use hidden or past information.', basis: 'Current percept', example: 'The lecture’s smart office rule' },
  { name: 'Model-based', key: 'model', short: 'Keep an internal state.', detail: 'It updates what it knows when new percepts arrive. This helps when sensors do not show the full state at one time.', basis: 'Percept + internal state', example: 'Remember what sensors cannot show' },
  { name: 'Goal-based', key: 'goal', short: 'Compare ways to reach a goal.', detail: 'It considers possible results and chooses an action that moves it toward a stated goal. Planning can help when one move changes later choices.', basis: 'Current state + goal', example: 'Plan a route to a destination' },
  { name: 'Utility-based', key: 'utility', short: 'Compare different outcomes.', detail: 'It gives outcomes a value, so it can compare choices when goals compete or results are uncertain.', basis: 'Expected utility', example: 'Balance safety, time and comfort' },
  { name: 'Learning-based', key: 'learning', short: 'Improve with experience.', detail: 'The Week 1 lecture includes learning in its agent design workflow. Later course topics explain learning methods in more detail.', basis: 'Past experience', example: 'Learning is studied later in the course' },
];
const cases = [
  { name: 'Pac-Man', tags: 'Sequential · dynamic', point: 'A move can change later choices. The agent can plan an escape route and consider when to use a power-up.' },
  { name: 'Self-driving', tags: 'Partially observable · dynamic', point: 'Sensors show objects, lanes and signals. The system predicts what nearby actors may do, then plans and controls the car.' },
  { name: 'Chess', tags: 'Observable · strategic', point: 'The board is visible, but an opponent makes decisions too. A chess agent must think about possible replies.' },
];

function SectionHeading({ number, title, label }) {
  return <div className="section-heading"><span className="section-number">{number}</span><h2>{title}</h2><span className="section-label mono">{label}</span></div>;
}

function OfficeDisplay() {
  return <div className="office-display" aria-label="Smart office agent reads room temperature and CO2 and chooses an action">
    <div className="office-room"><span className="room-label mono">ROOM 04 / LIVE PERCEPT</span><div className="room-window"><span className="window-sun" /><span className="window-line" /></div><div className="room-furniture desk" /><div className="room-furniture plant"><i /><i /><i /></div><div className="room-air"><Wind size={19} /><span>air flow</span></div></div>
    <div className="sensor-stack"><div><span>TEMPERATURE</span><strong>23<span>°C</span></strong></div><div><span>CO₂ LEVEL</span><strong>1200<span> ppm</span></strong></div><div className="sensor-action"><span>SELECTED ACTION</span><strong>Fresh-air fan ON</strong><small>Rule 03 matched</small></div></div>
  </div>;
}

function OfficeLab() {
  const [running, setRunning] = useState(false);
  const [program, setProgram] = useState('office');
  const examples = program === 'office'
    ? [['A', '18°C', '700 ppm', 'Heating ON', 'temperature < 20'], ['B', '23°C', '1200 ppm', 'Fresh-air fan ON', 'co2 > 1000'], ['C', '27°C', '800 ppm', 'Cooling ON', 'temperature > 26']]
    : [['A', '17°C', '—', 'Heater ON', 'temperature < 18'], ['B', '24°C', '85% humidity', 'Dehumidifier ON', 'humidity > 80'], ['C', '30°C', '—', 'Fan ON', 'temperature > 28']];
  const codeLines = program === 'office'
    ? ['def office_agent(temperature, co2):', '    if temperature < 20:', '        return "Heating ON"', '    elif temperature > 26:', '        return "Cooling ON"', '    elif co2 > 1000:', '        return "Fresh-air fan ON"', '    else:', '        return "No action"', '', 'print(office_agent(18, 700))', 'print(office_agent(23, 1200))', 'print(office_agent(27, 800))']
    : ['def greenhouse_agent(temperature, humidity):', '    if temperature < 18:', '        return "Heater ON"', '    elif temperature > 28:', '        return "Fan ON"', '    elif humidity > 80:', '        return "Dehumidifier ON"', '    else:', '        return "No action"', '', 'print(greenhouse_agent(24, 85))'];
  return <div className="office-lab">
    <div className="lab-copy"><span className="eyebrow">PYTHON MINI-LAB · FROM THE LECTURE</span><h3>Read the rule.<br />Predict the action.</h3><p>The function checks each condition from top to bottom. It returns the first matching action. Reveal the expected outputs and compare them with your predictions.</p><button className="button-primary" onClick={() => setRunning((value) => !value)}>{running ? <Check size={17} /> : <MoveRight size={17} />}{running ? 'Outputs shown' : 'Show expected outputs'}</button></div>
    <div className="code-panel"><div className="code-panel-head"><div className="code-tabs">{[['office', 'Smart office'], ['greenhouse', 'Greenhouse']].map(([id, label]) => <button key={id} className={program === id ? 'code-tab active' : 'code-tab'} onClick={() => { setProgram(id); setRunning(false); }}>{label}</button>)}</div><span className="live-badge"><span className="status-dot" />CLASS EXAMPLE</span></div><pre><code>{codeLines.join('\n')}</code></pre><div className="code-outputs">{examples.map(([id, temp, co2, action, rule]) => <div key={id} className={'code-result ' + (running ? 'checked' : '')}><span className="result-id">{id}</span><div><span className="result-input">{temp} · {co2}</span><strong>{running ? action : 'Ready to run'}</strong><small>{running ? rule : 'Input values from the lecture'}</small></div>{running && <Check size={16} />}</div>)}</div></div>
  </div>;
}

function QuickCheck() {
  const [answer, setAnswer] = useState('');
  return <div className="quick-check"><div><span className="eyebrow">QUICK CHECK</span><h3>What makes an agent rational?</h3><p>Choose the best answer, then read why.</p></div><div className="check-options">{[
    ['a', 'It always knows the true state of the world.'], ['b', 'It chooses the best expected action from the evidence it has.'],
  ].map(([id, text]) => <button key={id} className={'answer-option ' + (answer === id ? (id === 'b' ? 'correct' : 'incorrect') : '')} onClick={() => setAnswer(id)} aria-pressed={answer === id}><span>{id.toUpperCase()}</span>{text}{answer === id && id === 'b' ? <Check size={17} /> : <ArrowUpRight size={17} />}</button>)}<AnimatePresence mode="wait">{answer && <motion.p className="answer-feedback" role="status" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>{answer === 'b' ? 'Right. Rational does not mean all-knowing. The agent uses its evidence and expected performance to choose.' : 'A rational agent may have limited information. It chooses the best action it can support with the evidence it has.'}</motion.p>}</AnimatePresence></div></div>;
}

export default function App() {
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 130, damping: 30 });
  const [architecture, setArchitecture] = useState('reflex');
  const selectedArchitecture = architectures.find((item) => item.key === architecture);
  return <MotionConfig reducedMotion="user">
    <a href="#brief" className="skip-link">Skip to the case</a>
    <motion.div className="reading-progress" style={{ scaleX }} aria-hidden="true" />
    <header className="masthead page-width">
      <a href="#top" className="wordmark" aria-label="AI Case Files, back to top"><span className="brand-symbol"><GitBranch size={23} strokeWidth={1.6} /></span><span>AI CASE FILES<span className="wordmark-sub">A FIELD GUIDE TO THINKING MACHINES</span></span></a>
      <div className="masthead-right"><span>QAIRU</span><span className="masthead-divider" /><span>AI FUNDAMENTALS</span><a href="#sources" aria-label="View learning sources"><BookOpen size={18} /></a></div>
    </header>
    <CaseSelector />
    <main id="top">
      <section className="hero page-width" aria-labelledby="case-title">
        <div className="hero-meta"><span className="eyebrow"><span className="tiny-square" />CASE FILE #01</span><span className="hero-topic">WEEK 01 · AGENTS & ENVIRONMENTS</span></div>
        <div className="hero-body"><div className="hero-copy">
          <motion.h1 id="case-title" initial={reduced ? false : { opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, ease: [.2, .7, .2, 1] }}>Inside a<br /><span>Smart Office<span className="title-period">.</span></span></motion.h1>
          <p className="hero-description">A smart office reads room conditions and chooses what to do. Follow one simple example to learn how AI agents observe, decide and act.</p>
          <div className="hero-actions"><a href="#brief" className="read-link">Open the case <ArrowDown size={17} /></a><a href="#lab" className="hero-try">Try the lecture example <ArrowUpRight size={17} /></a></div>
        </div><div className="hero-visual"><span className="cover-folio">01</span><OfficeDisplay /><div className="visual-caption"><span className="caption-rule" /><span>OBSERVE.<br />CHOOSE AN ACTION.</span></div></div></div>
        <div className="hero-bottom"><div><Target size={15} /><span>DEFINE THE TASK</span><ArrowRight size={14} /><span>UNDERSTAND THE AGENT</span><ArrowRight size={14} /><span>CHECK ITS CHOICE</span></div><span className="mono">WEEK 01 / COMPLETE CASE</span></div>
      </section>

      <BookIntroduction />
      <section id="brief" className="chapter-section page-width">
        <SectionHeading number="01" title="The brief" label="START WITH THE PROBLEM" />
        <div className="brief-layout"><div className="brief-text"><p className="lead-paragraph">An intelligent agent receives information from its world and chooses an action. In our case, a smart office agent reads the room temperature and CO₂ level, then selects a suitable action.</p><p>The <strong>agent</strong> is the decision maker. The <strong>environment</strong> is everything around it that can affect what it observes or does. Sensors give the agent percepts, and actuators carry out its actions.</p><p>The office example uses simple rules, so we can trace its choice. Other tasks, such as Pac-Man, self-driving and chess, need different ways to decide because their worlds have different properties.</p></div>
          <div className="task-spec"><div className="task-spec-heading"><Target size={18} /><span>DEFINE SUCCESS FIRST</span></div><h3>What should the agent do?</h3><div className="spec-row"><span>Goal</span><strong>Choose an action for room conditions.</strong></div><div className="spec-row"><span>Inputs</span><strong>Temperature and CO₂ readings.</strong></div><div className="spec-row"><span>Measure</span><strong>Check the selected action and its result.</strong></div><p>A task description helps us decide what the agent needs to observe, what it can do and how to judge its behavior.</p></div></div>
      </section>

      <section id="agent" className="chapter-section page-width">
        <SectionHeading number="02" title="How an agent works" label="PERCEIVE → DECIDE → ACT" />
        <p className="section-lead">The agent and its environment form a loop. The agent gets a percept from its sensors, chooses an action and affects the environment. The next percept shows what happened.</p>
        <div className="agent-loop-panel"><div className="loop-flow">{[['01', Eye, 'Percept', 'Read the temperature and CO₂.'], ['02', GitBranch, 'Decision', 'Apply the agent’s rules.'], ['03', MoveRight, 'Action', 'Turn heating, cooling or fresh air on.']].map(([num, Icon, title, body], i) => <div className="loop-step" key={num}><span className="loop-index">{num}</span><Icon size={27} /><h3>{title}</h3><p>{body}</p>{i < 2 && <ArrowRight className="loop-arrow" size={24} />}</div>)}</div><div className="loop-return"><span>THE ACTION CHANGES THE ROOM</span><span className="return-line" /><span>NEW PERCEPT</span></div></div>
        <div className="rationality-grid"><div className="rationality-heading"><span className="eyebrow">RATIONALITY</span><h3>A good choice uses the evidence available.</h3><p>A rational agent chooses the action with the best expected performance. It cannot always know everything. Its choice depends on what it has observed and what the task counts as success.</p></div><div className="rationality-factors">{[['Performance', 'What counts as success?'], ['Beliefs', 'What does the agent expect?'], ['Actions', 'What can it do?'], ['Evidence', 'What has it observed?']].map(([title, text], i) => <div className="factor-row" key={title}><span>0{i + 1}</span><strong>{title}</strong><p>{text}</p></div>)}</div></div>
        <QuickCheck />
      </section>

      <section id="peas" className="chapter-section page-width">
        <SectionHeading number="03" title="Describe the task with PEAS" label="SPECIFY BEFORE YOU DESIGN" />
        <p className="section-lead">PEAS turns a broad task into a clear description. It names how we judge success, where the agent works, how it acts and what information it receives.</p>
        <div className="peas-feature"><div className="peas-intro"><span className="peas-stamp">P·E·A·S</span><h3>One task.<br />Four useful questions.</h3><p>These details guide the agent design. The answer changes from one task to another.</p></div><dl className="peas-list">{[['P', 'Performance measure', 'How do we know that it did well?'], ['E', 'Environment', 'What world does it work in?'], ['A', 'Actuators', 'How can it act on that world?'], ['S', 'Sensors', 'What information can it receive?']].map(([letter, title, desc]) => <div className="peas-row" key={letter}><dt><span>{letter}</span>{title}</dt><dd>{desc}</dd></div>)}</dl></div>
        <div className="office-peas"><span className="eyebrow">THE SMART OFFICE · PEAS</span><div><p><b>P</b><span><strong>Performance</strong>Check the action against the stated rules.</span></p><p><b>E</b><span><strong>Environment</strong>The office room and its changing conditions.</span></p><p><b>A</b><span><strong>Actuators</strong>Heating, cooling and fresh-air fan.</span></p><p><b>S</b><span><strong>Sensors</strong>Temperature and CO₂ readings.</span></p></div></div>
        <div className="peas-examples"><span className="eyebrow">OTHER LECTURE EXAMPLES</span>{[
          ['Self-driving car', 'Safety, travel time and comfort', 'Roads, traffic, weather and pedestrians', 'Steering, throttle and brakes', 'Cameras, radar, lidar and GPS'],
          ['Pac-Man', 'Score, survival and completion', 'Maze, ghosts, pellets and power-ups', 'Move up, down, left or right', 'Grid position, visible maze and events'],
          ['Chess', 'Win, avoid loss and position', 'Board, legal moves, opponent and clock', 'Choose a legal move', 'Board, move history and clock'],
        ].map(([name, p, e, a, s]) => <article className="peas-example" key={name}><h3>{name}</h3><p><b>P</b>{p}</p><p><b>E</b>{e}</p><p><b>A</b>{a}</p><p><b>S</b>{s}</p></article>)}</div>
      </section>

      <section id="world" className="chapter-section page-width">
        <SectionHeading number="04" title="Read the environment" label="WAYS TO CLASSIFY A WORLD" />
        <div className="world-intro"><p className="section-lead">An environment can be described with a few pairs of properties. These words help explain what the agent can know, what can change and what kind of actions it can use.</p><span className="taxonomy-mark">WORLD<br />TYPES / 06</span></div>
        <div className="environment-grid">{environments.map(({ title, options, detail, icon: Icon }, i) => <article className="environment-card" key={title}><div className="environment-card-top"><span>0{i + 1}</span><Icon size={21} /></div><h3>{title}</h3><strong>{options}</strong><p>{detail}</p></article>)}</div>
        <div className="taxonomy-note"><ShieldCheck size={20} /><p>One task can have several properties at the same time. For example, the lecture describes Pac-Man as sequential and dynamic, and chess as observable and strategic.</p></div>
      </section>

      <section id="architectures" className="chapter-section page-width">
        <SectionHeading number="05" title="Choose an agent design" label="MORE REASONING, MORE WORK" />
        <p className="section-lead">Agent architectures use different information to choose actions. A simple design can be fast, while a richer design can compare more possible outcomes.</p>
        <div className="architecture-explorer"><div className="architecture-tabs" role="tablist" aria-label="Agent architectures">{architectures.map((item, i) => <button key={item.key} role="tab" aria-selected={architecture === item.key} className={architecture === item.key ? 'architecture-tab active' : 'architecture-tab'} onClick={() => setArchitecture(item.key)}><span>0{i + 1}</span>{item.name}<ChevronRight size={17} /></button>)}</div><AnimatePresence mode="wait"><motion.article key={architecture} className="architecture-detail" role="tabpanel" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} transition={{ duration: .22 }}><span className="eyebrow">{selectedArchitecture.name.toUpperCase()} AGENT</span><h3>{selectedArchitecture.short}</h3><p>{selectedArchitecture.detail}</p><div className="architecture-meta"><div><span>USES</span><strong>{selectedArchitecture.basis}</strong></div><div><span>LECTURE LINK</span><strong>{selectedArchitecture.example}</strong></div></div><div className="architecture-scale"><span>FASTER / SIMPLER</span><span className="scale-line"><i style={{ width: ((architectures.findIndex((item) => item.key === architecture) + 1) * 25) + '%' }} /></span><span>RICHER / MORE COMPUTATION</span></div></motion.article></AnimatePresence></div>
        <div className="case-study-grid">{cases.map((item, i) => <article className="case-study" key={item.name}><span className="case-study-number">CASE 0{i + 1}</span><span className="case-study-tags">{item.tags}</span><h3>{item.name}</h3><p>{item.point}</p></article>)}</div>
      </section>

      <section id="lab" className="chapter-section page-width">
        <SectionHeading number="06" title="Try the lecture example" label="RULES → ACTIONS" />
        <p className="section-lead">The lecture uses a smart office to show how Python rules connect percepts to actions. Read the code and predict each result before you reveal the expected outputs.</p>
        <OfficeLab />
        <div className="priority-note"><Scale size={20} /><p>Only the first matching branch runs. If more than one condition is true, the order of the rules can change the action. The lecture asks you to test cases and explain which rule wins.</p></div>
      </section>

      <section id="formulation" className="chapter-section page-width">
        <SectionHeading number="07" title="Formulate a problem" label="FROM A GOAL TO A SEARCH TASK" />
        <p className="section-lead">When a reflex rule is not enough, a goal-based agent can plan. A search problem needs five clear parts before we choose a search method.</p>
        <div className="problem-steps">{[['01', 'Initial state', 'Where does the problem start?'], ['02', 'Actions', 'Which moves are allowed?'], ['03', 'Transition model', 'What happens after an action?'], ['04', 'Goal test', 'How do we know we reached the goal?'], ['05', 'Path cost', 'How much does a route cost?']].map(([n, title, text], i) => <div className="problem-step" key={title}><span>{n}</span><div><h3>{title}</h3><p>{text}</p></div>{i < 4 && <ArrowRight className="problem-arrow" size={19} />}</div>)}</div>
        <div className="bridge-cards"><div className="bridge-card"><span className="eyebrow">NEXT COURSE CONNECTION · WEEK 02</span><h3>Now a search algorithm can solve the problem.</h3><p>Week 1 gives the task structure. Week 2 studies search methods such as BFS, DFS, UCS and A*.</p></div><div className="bridge-card mdp-bridge"><span className="eyebrow">A SECOND COURSE CONNECTION · WEEK 05</span><h3>Decisions can include uncertain results.</h3><p>A Markov decision process describes states, actions, transition probabilities, rewards and a policy. The policy aims to maximize expected total reward over time.</p></div></div>
      </section>

      <section id="evaluation" className="chapter-section page-width">
        <SectionHeading number="08" title="Evaluate the agent" label="CHECK RESULTS ACROSS TASKS" />
        <div className="evaluation-grid"><div><span className="eyebrow">TASK PERFORMANCE</span><h3>Did the agent do the job?</h3><p>Use measures that fit the task, such as score, reward, safety or time. For the office example, check whether the selected action follows the stated rules.</p></div><div><span className="eyebrow">MODEL METRICS</span><h3>How well did a prediction work?</h3><p>Precision, recall and F1 measure a prediction model. They answer a different question from whether an agent completed its task.</p></div><div><span className="eyebrow">ROBUSTNESS</span><h3>Does it work in new situations?</h3><p>Try different scenarios and boundary values. A reliable explanation includes where the agent succeeds and where it needs a better design.</p></div></div>
        <div className="workflow-strip"><span className="eyebrow">DESIGN WORKFLOW</span><div>{['PEAS', 'CLASSIFY', 'REPRESENT', 'DESIGN', 'EVALUATE'].map((item, i) => <span key={item}>{i > 0 && <ArrowRight size={15} />}{item}</span>)}</div></div>
      </section>

      <section id="sources" className="sources-section page-width"><div><span className="eyebrow">LEARNING NOTES</span><h3>Built from Week 1.</h3></div><div><p><strong>Main source:</strong> QAIRU AI Fundamentals, Week 1, <em>Introduction, Agents, and Environments</em>. The smart office rules, PEAS examples, agent types, problem parts, case studies and evaluation terms follow that lecture.</p><p>The office readings and actions shown here are the lecture example. The interactive page helps explain them; it does not add a new course algorithm.</p></div></section>
    </main>
    <footer className="footer page-width"><a href="#top" className="footer-brand">AI CASE FILES<span>01</span></a><span>QAIRU · AI FUNDAMENTALS · WEEK 01</span><a href="#top">Back to top <ArrowUpRight size={16} /></a></footer>
  </MotionConfig>;
}
