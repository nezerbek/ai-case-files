import { HMMNotes } from './components/CourseNotes';
import { useMemo, useState } from 'react';
import { motion, MotionConfig } from 'framer-motion';
import { ArrowRight, BookOpen, Check, GitBranch, MapPin, Radio, RefreshCw, ScanEye } from 'lucide-react';
import CaseSelector from './components/CaseSelector';

const states = ['A', 'B', 'C'];
const transition = [[0.7, 0.3, 0], [0.2, 0.6, 0.2], [0, 0.3, 0.7]];
const emission = { RED: [0.8, 0.5, 0.2], BLUE: [0.2, 0.5, 0.8] };
const observations = ['RED', 'BLUE', 'BLUE', 'RED'];
const hmmCode = `states = ["A", "B", "C"]
T = [[0.7, 0.3, 0.0],
     [0.2, 0.6, 0.2],
     [0.0, 0.3, 0.7]]
emission = {"RED": [0.8, 0.5, 0.2],
            "BLUE": [0.2, 0.5, 0.8]}
belief = [0.5, 0.3, 0.2]
readings = ["RED", "BLUE", "BLUE", "RED"]

def predict(b, T):
    return [sum(b[i] * T[i][j] for i in range(3))
            for j in range(3)]

def update(pred, likelihood):
    weights = [pred[i] * likelihood[i]
               for i in range(3)]
    total = sum(weights)
    return [w / total for w in weights]

for reading in readings:
    belief = update(predict(belief, T), emission[reading])
    print(reading, [round(v, 4) for v in belief])`;

function advance(belief, reading) {
  const predicted = states.map((_, to) => belief.reduce((sum, value, from) => sum + value * transition[from][to], 0));
  const weighted = predicted.map((value, i) => value * emission[reading][i]);
  const total = weighted.reduce((sum, value) => sum + value, 0);
  return { predicted, belief: weighted.map((value) => value / total) };
}

function HMMLab() {
  const [step, setStep] = useState(0);
  const history = useMemo(() => {
    let belief = [0.5, 0.3, 0.2];
    return observations.slice(0, step).map((reading) => {
      const result = advance(belief, reading);
      belief = result.belief;
      return { reading, ...result };
    });
  }, [step]);
  const current = history.at(-1);
  const belief = current?.belief ?? [0.5, 0.3, 0.2];
  const predicted = current?.predicted;
  const mostLikely = states[belief.indexOf(Math.max(...belief))];
  return <div className="w7-hmm-lab"><div className="w7-lab-head"><div><span className="eyebrow">PRACTICE 7 · ROBOT LOCALIZATION</span><h3>{step === 0 ? 'Start with a belief about the zones.' : `Reading ${step}: ${observations[step - 1]}`}</h3><p>{step === 0 ? 'The robot is hidden in one of three zones. Use the practice readings in order to update its location estimate.' : `First predict where the robot may move, then use the ${observations[step - 1]} sensor reading to update the belief.`}</p></div><div className="w7-lab-count">{step}<span>/ 4 readings</span></div></div><div className="w7-zone-beliefs">{states.map((zone, i) => <article key={zone} className={mostLikely === zone ? 'most-likely' : ''}><div><MapPin size={15} /><span>ZONE {zone}</span>{mostLikely === zone && <Check size={14} />}</div><strong>{(belief[i] * 100).toFixed(1)}<small>%</small></strong><i><b style={{ width: `${belief[i] * 100}%` }} /></i>{predicted && <small>Prediction: {(predicted[i] * 100).toFixed(1)}%</small>}</article>)}</div><div className="w7-lab-footer"><p>{step === 0 ? 'Initial belief: 50% in A, 30% in B and 20% in C.' : `Most likely zone now: ${mostLikely}. This is an estimate, not a known location.`}</p><button className="w7-next" onClick={() => setStep(step >= 4 ? 0 : step + 1)}>{step >= 4 ? <><RefreshCw size={15} /> Run it again</> : <>{step === 0 ? 'Process first reading' : `Process ${observations[step]} reading`} <ArrowRight size={15} /></>}</button></div><div className="w7-readings" aria-label="Observation sequence">{observations.map((reading, i) => <span key={i} className={i < step ? 'done' : i === step ? 'next' : ''}><small>T{i + 1}</small>{reading}</span>)}</div></div>;
}

export default function Week7() {
  return <MotionConfig reducedMotion="user">
    <a href="#brief" className="skip-link">Skip to the case</a><div className="reading-progress reading-progress-static" aria-hidden="true" />
    <header className="masthead page-width"><a href="?case=01#top" className="wordmark" aria-label="AI Case Files, open the case index"><span className="brand-symbol"><GitBranch size={23} strokeWidth={1.6} /></span><span>AI CASE FILES<span className="wordmark-sub">A FIELD GUIDE TO THINKING MACHINES</span></span></a><div className="masthead-right"><span>QAIRU</span><span className="masthead-divider" /><span>AI FUNDAMENTALS</span><a href="#sources" aria-label="View learning sources"><BookOpen size={18} /></a></div></header>
    <CaseSelector week="07" />
    <main id="top" className="week7-page">
      <section className="hero page-width" aria-labelledby="case-title"><div className="hero-meta"><span className="eyebrow"><span className="tiny-square" />CASE FILE #07</span><span className="hero-topic">WEEK 07 · HIDDEN MARKOV MODELS</span></div><div className="hero-body"><div className="hero-copy"><motion.h1 id="case-title" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .45 }}>Track what<br />you cannot <span>see<span className="title-period">.</span></span></motion.h1><p className="hero-description">A robot’s true location is hidden. Its sensor gives clues, and its location can change. An HMM combines movement and readings to update the location estimate over time.</p><div className="hero-actions"><a href="#brief" className="read-link">Open the case <ArrowRight size={17} /></a><a href="#filtering" className="hero-try">Track four readings <ArrowRight size={15} /></a></div></div><div className="hero-visual w7-hero-visual"><span className="cover-folio">07</span><div className="w7-cover-map"><div className="w7-map-head"><span>HIDDEN LOCATION</span><span>NOISY SENSOR</span></div><div className="w7-map-zones"><span>A<i /></span><span>B<i /></span><span>C<i /></span></div><div className="w7-map-signal"><Radio size={16} /><b>RED</b><span>→</span><strong>ZONE A · 58.3%</strong></div><div className="w7-map-foot">BELIEF CHANGES WITH EACH READING</div></div><div className="visual-caption"><span className="caption-rule" /><span>PREDICT.<br />OBSERVE.<br />UPDATE.</span></div></div></div><div className="hero-bottom"><div><ScanEye size={15} /><span>HIDDEN STATE</span><ArrowRight size={14} /><span>SENSOR READING</span><ArrowRight size={14} /><span>NEW BELIEF</span></div><span className="mono">WEEK 07 / SEQUENTIAL INFERENCE</span></div></section>

      <section id="brief" className="chapter-section page-width"><div className="section-heading"><span className="section-number">01</span><h2>The state is hidden, but clues arrive</h2><span className="section-label mono">ROBOT LOCALIZATION</span></div><div className="brief-layout"><div className="brief-text"><p className="lead-paragraph">Practice 7 places a robot in warehouse zones A, B and C. We cannot see its true zone. A sensor reports RED or BLUE, but the reading can be wrong.</p><p>The robot may move between readings. A Hidden Markov Model, or HMM, describes both how the hidden state changes and how each state can produce a sensor reading.</p><p>Its belief is a probability for every zone. These numbers add to 1. A reading changes our estimate; it does not prove the robot’s exact location.</p></div><div className="w7-hmm-structure"><div className="w7-structure-row"><span className="eyebrow">HIDDEN STATE</span><div><i>A</i><ArrowRight /><i>B</i><ArrowRight /><i>C</i></div><small>Transition: how the location can change</small></div><div className="w7-structure-connector"><span /><span /><span /></div><div className="w7-structure-row observation"><span className="eyebrow">OBSERVATION</span><div><b>RED / BLUE</b><Radio size={17} /></div><small>Emission: what the sensor may report</small></div></div></div><div className="w7-matrix-pair"><article><span className="eyebrow">TRANSITION · FROM → TO</span><table><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr></thead><tbody><tr><th>A</th><td>0.70</td><td>0.30</td><td>0.00</td></tr><tr><th>B</th><td>0.20</td><td>0.60</td><td>0.20</td></tr><tr><th>C</th><td>0.00</td><td>0.30</td><td>0.70</td></tr></tbody></table><p>Each row says where the robot can move from that zone.</p></article><article><span className="eyebrow">EMISSION · SENSOR READING</span><table><thead><tr><th>Zone</th><th>RED</th><th>BLUE</th></tr></thead><tbody><tr><th>A</th><td>0.80</td><td>0.20</td></tr><tr><th>B</th><td>0.50</td><td>0.50</td></tr><tr><th>C</th><td>0.20</td><td>0.80</td></tr></tbody></table><p>Each row says how likely each reading is in that zone.</p></article></div></section>

      <section id="filtering" className="chapter-section page-width"><div className="section-heading"><span className="section-number">02</span><h2>Predict, then use the sensor clue</h2><span className="section-label mono">FILTERING · PRACTICE 7</span></div><p className="section-lead">For every reading, the filter first predicts the next location from the transition matrix. It then gives more weight to zones that fit the reading and normalizes the probabilities.</p><div className="w7-filter-equation"><div><span>01 · PREDICT</span><strong>pₜ(j) = Σᵢ bₜ₋₁(i) Tᵢⱼ</strong></div><ArrowRight /><div><span>02 · WEIGHT</span><strong>wₜ(j) = pₜ(j) P(Eₜ | j)</strong></div><ArrowRight /><div><span>03 · NORMALIZE</span><strong>bₜ(j) = wₜ(j) / Σⱼ wₜ(j)</strong></div></div><HMMLab /><div className="w7-rounding-note">The practice sequence is RED → BLUE → BLUE → RED. After all four readings, the most likely zone is B (50.58%). Probabilities in the display are rounded to one decimal place.</div></section>

      <section id="tasks" className="chapter-section page-width"><div className="section-heading"><span className="section-number">03</span><h2>Choose the question before the method</h2><span className="section-label mono">FILTER · PREDICT · SMOOTH · DECODE</span></div><div className="w7-task-grid"><article><span className="eyebrow">FILTERING</span><h3>What is the state now?</h3><p>Use the readings received up to the current time. In the practice, each new reading updates the robot’s current location belief.</p><b className="w7-task-number">PRACTICE 7</b></article><article><span className="eyebrow">PREDICTION</span><h3>What may happen next?</h3><p>Move the current belief forward with the transition matrix. No new sensor reading is used for this future estimate.</p><b className="w7-task-number">NEXT STATE</b></article><article><span className="eyebrow">SMOOTHING</span><h3>What was the earlier state?</h3><p>Use later readings to improve an estimate of an earlier time. With two HIGH readings, the lecture estimates Faulty₁ at 67.7%.</p><b className="w7-task-number">PAST + LATER EVIDENCE</b></article><article><span className="eyebrow">VITERBI</span><h3>What is the best full path?</h3><p>Keep the best path ending at each state, then trace the winning path back. For the lecture’s HIGH, HIGH example, it gives [Faulty, Faulty].</p><b className="w7-task-number">ONE STATE SEQUENCE</b></article></div><div className="w7-sum-max"><span className="eyebrow">TWO DIFFERENT QUESTIONS</span><div><p><strong>Filtering adds</strong> possible paths to estimate state probabilities.</p><span>SUM</span><p><strong>Viterbi chooses</strong> one complete path with the highest probability.</p><span>MAX</span></div></div></section>

      <section id="python" className="chapter-section page-width"><div className="section-heading"><span className="section-number">04</span><h2>Turn the two steps into Python</h2><span className="section-label mono">PRACTICE 7 CODE</span></div><div className="w7-python-intro"><p>The practice uses a small list of states and loops through the readings. After each sensor reading, it saves the new belief and uses it for the next step.</p><div className="w7-python-result"><span>FINAL BELIEF · A / B / C</span><strong>0.3104 / 0.5058 / 0.1838</strong><small>Most likely: Zone B</small></div></div><div className="w7-code-card"><div className="code-panel-head"><span className="eyebrow">PYTHON · PRACTICE 7</span><span className="code-slide-ref">PREDICT + UPDATE</span></div><pre><code>{hmmCode}</code></pre><p>The code follows the same prediction and filtering formulas shown above. No library is needed for this practice example.</p></div><div className="w7-assumption"><span className="eyebrow">MODEL ASSUMPTION</span><p>The next state depends on the current state. Once the current state is known, its reading depends on that state. The probabilities must come from the model or data.</p></div></section>

      <HMMNotes />
      <section id="sources" className="sources-section page-width"><div><span className="eyebrow">LEARNING NOTES</span><h3>Built from Week 7.</h3></div><div><p><strong>Main source:</strong> QAIRU AI Fundamentals, Week 7, <em>Hidden Markov Models</em>. The machine states, filtering example, prediction, smoothing and Viterbi results follow the lecture.</p><p><strong>Practice source:</strong> Practice 7, <em>Robot Localization with HMMs</em>. The A/B/C zones, transition and emission matrices, four readings and Python filter use the course example.</p></div></section>
    </main><footer className="footer page-width"><a href="?case=07#top" className="footer-brand">AI CASE FILES<span>07</span></a><span>QAIRU · AI FUNDAMENTALS · WEEK 07</span><a href="#top">Back to top <ArrowRight size={16} /></a></footer>
  </MotionConfig>;
}
