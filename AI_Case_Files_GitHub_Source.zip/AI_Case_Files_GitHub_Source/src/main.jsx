import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import Week2 from './Week2';
import Week3 from './Week3';
import Week4 from './Week4';
import Week5 from './Week5';
import Week6 from './Week6';
import Week7 from './Week7';
import Week8 from './Week8';
import './styles.css';

function Casebook() {
  const week = new URLSearchParams(window.location.search).get('case');
  if (week === '02') return <Week2 />;
  if (week === '03') return <Week3 />;
  if (week === '04') return <Week4 />;
  if (week === '05') return <Week5 />;
  if (week === '06') return <Week6 />;
  if (week === '07') return <Week7 />;
  if (week === '08') return <Week8 />;
  return <App />;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><Casebook /></React.StrictMode>);
