import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowUpRight, Check, ChevronDown, FolderOpen } from 'lucide-react';

const sections = [['brief', '01', 'The task'], ['peas', '02', 'PEAS'], ['architectures', '03', 'Agent design']];

export default function CaseSelector({ week = '01' }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('brief');
  const sections = week === '02'
    ? [['brief', '01', 'The task'], ['strategies', '02', 'Search strategies'], ['lab', '03', 'Route costs'], ['heuristics', '04', 'A*']]
    : week === '03'
      ? [['brief', '01', 'The task'], ['hill-climbing', '02', 'Hill climbing'], ['escape', '03', 'Escape local peaks'], ['methods', '04', 'Other methods']]
      : week === '04'
        ? [['brief', '01', 'The game'], ['minimax', '02', 'Minimax'], ['pruning', '03', 'Alpha–Beta'], ['limits', '04', 'Depth & chance']]
        : week === '05'
          ? [['brief', '01', 'The decision'], ['mdp', '02', 'MDP model'], ['planning', '03', 'Planning'], ['learning', '04', 'Reinforcement learning']]
          : week === '06'
            ? [['brief', '01', 'The evidence'], ['bayes', '02', 'Bayes’ theorem'], ['network', '03', 'Bayesian network'], ['inference', '04', 'Inference']]
          : week === '07'
            ? [['brief', '01', 'Hidden state'], ['filtering', '02', 'Filtering'], ['tasks', '03', 'Past estimate'], ['python', '04', 'Python code']]
            : week === '08'
              ? [['brief', '01', 'Rational choice'], ['utility', '02', 'Expected utility'], ['uncertainty', '03', 'Risk & Bayes'], ['learning', '04', 'Classical ML'], ['decisions', '05', 'From prediction to action'], ['evaluation', '06', 'Model checks']]
    : [['brief', '01', 'The task'], ['peas', '02', 'PEAS'], ['architectures', '03', 'Agent design']];
  const ref = useRef(null);
  const trigger = useRef(null);

  useEffect(() => {
    const close = (event) => {
      if (event.type === 'keydown' && event.key === 'Escape') { setOpen(false); trigger.current?.focus(); }
      if (event.type === 'pointerdown' && !ref.current?.contains(event.target)) setOpen(false);
    };
    document.addEventListener('pointerdown', close);
    document.addEventListener('keydown', close);
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => { if (entry.isIntersecting) setActive(entry.target.id); });
    }, { rootMargin: '-20% 0px -50% 0px', threshold: 0 });
    sections.forEach(([id]) => { const el = document.getElementById(id); if (el) observer.observe(el); });
    return () => {
      document.removeEventListener('pointerdown', close);
      document.removeEventListener('keydown', close);
      observer.disconnect();
    };
  }, []);

  return <div className="case-dock-wrap" ref={ref}>
    <div className="case-dock">
      <button ref={trigger} className="case-trigger" aria-expanded={open} aria-controls="case-index" onClick={() => setOpen(!open)}>
        <FolderOpen size={17} /><span>CASE <b>{week}</b></span><ChevronDown className={open ? 'rotate-180' : ''} size={15} />
      </button>
      <nav aria-label="Sections in this case" className="section-nav">
        {sections.map(([id, number, label]) => <a key={id} href={`#${id}`} className={active === id ? 'active' : ''} onClick={() => setActive(id)} aria-current={active === id ? 'location' : undefined}>
          <span className="section-nav-number">{number}</span>{label}
          {active === id && <motion.span layoutId="section-line" className="section-line" transition={{ type: 'spring', stiffness: 400, damping: 35 }} />}
        </a>)}
      </nav>
      <span className="dock-status"><span className="status-dot" />WEEK {week} / {week === '02' ? 'SEARCH' : week === '03' ? 'OPTIMIZATION' : week === '04' ? 'GAME TREES' : week === '05' ? 'MDP / RL' : week === '06' ? 'BAYES / NETWORKS' : week === '07' ? 'HMM' : week === '08' ? 'RATIONAL ML' : 'AGENTS'}</span>
    </div>
    <AnimatePresence>{open && <motion.div id="case-index" className="case-index" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
      <div className="index-heading"><span>THE CASE INDEX</span><span>8 cases</span></div>
      <a href="?case=01#top" className={'index-entry ' + (week === '01' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">01</span><span><strong>Inside a Smart Office</strong><small>Agents and environments · Week 1</small></span>{week === '01' && <Check size={18} />}</a>
      <a href="?case=02#top" className={'index-entry ' + (week === '02' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">02</span><span><strong>Search the Route</strong><small>BFS, DFS, UCS and A* · Week 2</small></span>{week === '02' && <Check size={18} />}</a>
      <a href="?case=03#top" className={'index-entry ' + (week === '03' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">03</span><span><strong>Improve the Configuration</strong><small>Local search and optimization · Week 3</small></span>{week === '03' && <Check size={18} />}</a>
      <a href="?case=04#top" className={'index-entry ' + (week === '04' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">04</span><span><strong>Think Ahead in a Game</strong><small>Minimax, Alpha–Beta and Expectimax · Week 4</small></span>{week === '04' && <Check size={18} />}</a>
      <a href="?case=05#top" className={'index-entry ' + (week === '05' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">05</span><span><strong>Learn from Consequences</strong><small>MDPs and reinforcement learning · Week 5</small></span>{week === '05' && <Check size={18} />}</a>
      <a href="?case=06#top" className={'index-entry ' + (week === '06' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">06</span><span><strong>Reason from Evidence</strong><small>Bayes’ theorem and networks · Week 6</small></span>{week === '06' && <Check size={18} />}</a>
      <a href="?case=07#top" className={'index-entry ' + (week === '07' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">07</span><span><strong>Track What You Cannot See</strong><small>Hidden Markov Models · Week 7</small></span>{week === '07' && <Check size={18} />}</a>
      <a href="?case=08#top" className={'index-entry ' + (week === '08' ? 'selected' : '')} onClick={() => setOpen(false)}><span className="index-num">08</span><span><strong>Choose with Evidence</strong><small>Rational decisions and classical ML · Week 8</small></span>{week === '08' && <Check size={18} />}</a>
      <p>Each case turns one course week into a guided example.</p>
    </motion.div>}</AnimatePresence>
  </div>;
}
