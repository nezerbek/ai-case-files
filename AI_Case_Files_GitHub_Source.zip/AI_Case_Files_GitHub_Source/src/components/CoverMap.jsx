import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowUpRight, Crosshair } from 'lucide-react';
import { breadthFirstSearch, COLS, GOAL, INITIAL_WALLS, ROWS, START } from '../lib/grid';

const route = breadthFirstSearch(START, GOAL, new Set(INITIAL_WALLS)).path;

export default function CoverMap() {
  const reduced = useReducedMotion();
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 650], [0, -32]);
  return <motion.div className="cover-map" style={{ y: reduced ? 0 : y }} aria-hidden="true">
    <div className="cover-map-top"><span>ENVIRONMENT / 10 × 7</span><Crosshair size={15} /></div>
    <div className="cover-grid">
      {Array.from({ length: ROWS * COLS }, (_, id) => <div key={id} className={`cover-cell ${INITIAL_WALLS.includes(id) ? 'wall' : ''} ${route.includes(id) ? 'route' : ''} ${id === START ? 'start' : ''} ${id === GOAL ? 'goal' : ''}`}>
        {id === START ? <Crosshair size={17} /> : id === GOAL ? <ArrowUpRight size={19} /> : route.includes(id) ? <span /> : null}
      </div>)}
    </div>
    <div className="cover-map-bottom"><span>OBSERVE. PLAN. ACT.</span><span>{route.length - 1} MOVES</span></div>
    <div className="map-corner corner-a" /><div className="map-corner corner-b" />
  </motion.div>;
}
