import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Check, Crosshair, Flag, Pause, Play, RotateCcw, Square, StepForward } from 'lucide-react';
import { breadthFirstSearch, COLS, coordinates, GOAL, INITIAL_WALLS, ROWS, START } from '../lib/grid';

function position(id) { const { row, col } = coordinates(id); return `[${row}, ${col}]`; }

export default function Simulator() {
  const [walls, setWalls] = useState(new Set(INITIAL_WALLS));
  const [goal, setGoal] = useState(GOAL);
  const [tool, setTool] = useState('wall');
  const [cursor, setCursor] = useState(0);
  const [running, setRunning] = useState(false);
  const [speed, setSpeed] = useState('normal');
  const [notice, setNotice] = useState('Choose a tool and click the map, or run the example as it is.');
  const [focused, setFocused] = useState(START);
  const reduced = useReducedMotion();
  const result = useMemo(() => breadthFirstSearch(START, goal, walls), [goal, walls]);
  const searchSteps = result.snapshots.length;
  const totalSteps = searchSteps + (result.found ? result.path.length - 1 : 0);
  const searchDone = cursor >= searchSteps;
  const complete = cursor >= totalSteps && cursor > 0;
  const snapshot = result.snapshots[Math.min(cursor, searchSteps) - 1];
  const routeIndex = Math.max(0, cursor - searchSteps);
  const agent = searchDone && result.found ? result.path[routeIndex] : START;
  const expanded = new Set(snapshot?.expanded || []);
  const frontier = new Set(snapshot?.frontier || []);
  const path = new Set(searchDone ? result.path : []);

  useEffect(() => {
    if (!running) return;
    if (cursor >= totalSteps) { setRunning(false); return; }
    const timer = setTimeout(() => setCursor((value) => Math.min(value + 1, totalSteps)), speed === 'fast' ? 45 : 140);
    return () => clearTimeout(timer);
  }, [running, cursor, totalSteps, speed]);

  function resetProgress() { setRunning(false); setCursor(0); }
  function editCell(id) {
    if (id === START) { setNotice('The start stays here. Choose another cell to edit.'); return; }
    if (tool === 'wall' && id === goal) { setNotice('Move the goal before placing a wall on this cell.'); return; }
    resetProgress();
    if (tool === 'goal') {
      setGoal(id); setWalls((old) => { const next = new Set(old); next.delete(id); return next; });
      setNotice(`Goal moved to ${position(id)}. Run the agent to find a new route.`);
    } else {
      const removing = walls.has(id);
      setWalls((old) => { const next = new Set(old); if (next.has(id)) next.delete(id); else next.add(id); return next; });
      setNotice(`Wall ${removing ? 'removed from' : 'added at'} ${position(id)}. The agent will plan again from the start.`);
    }
  }
  function resetMap() {
    resetProgress(); setWalls(new Set(INITIAL_WALLS)); setGoal(GOAL); setTool('wall');
    setNotice('The original map is back. Try a different route.');
  }
  function toggleRun() {
    if (running) { setRunning(false); return; }
    if (complete) setCursor(0);
    setRunning(true);
  }
  function nextStep() {
    setRunning(false);
    setCursor((value) => value >= totalSteps ? 1 : value + 1);
  }
  function handleKey(event, id) {
    const delta = { ArrowUp: -COLS, ArrowDown: COLS, ArrowLeft: -1, ArrowRight: 1 }[event.key];
    if (delta === undefined) return;
    event.preventDefault();
    const next = id + delta;
    if (next < 0 || next >= ROWS * COLS || (event.key === 'ArrowLeft' && id % COLS === 0) || (event.key === 'ArrowRight' && id % COLS === COLS - 1)) return;
    setFocused(next); document.getElementById(`grid-cell-${next}`)?.focus();
  }
  const phase = cursor === 0 ? 'Ready to explore' : !searchDone ? 'Looking for a route' : !result.found ? 'No route available' : complete ? 'Goal reached' : 'Following the route';
  const explanation = cursor === 0
    ? 'The agent knows the whole map. It will first plan a route, then move along it.'
    : !searchDone
      ? `BFS is checking cell ${position(snapshot.current)}. New cells join the end of the queue. The agent has not moved yet.`
      : !result.found
        ? 'The queue is empty, and the goal was not reached. Remove a wall or move the goal, then try again.'
        : complete
          ? `The agent reached ${position(goal)} in ${result.path.length - 1} moves. Every move costs 1, so BFS found a route with the fewest moves.`
          : `Planning is complete. The agent is now following its route. It has made ${routeIndex} of ${result.path.length - 1} moves.`;

  return <div className="simulator-shell">
    <div className="sim-toolbar">
      <div className="tool-group" aria-label="Map editing tools">
        {[['wall', Square, 'Edit walls'], ['goal', Flag, 'Move goal']].map(([name, Icon, label]) => <button key={name} aria-pressed={tool === name} className={tool === name ? 'tool active' : 'tool'} onClick={() => { setTool(name); setNotice(name === 'wall' ? 'Click an empty cell to add a wall. Click a wall to remove it.' : 'Click a cell to move the goal.'); }}><Icon size={15} />{label}</button>)}
      </div>
      <button className="reset-button" onClick={resetMap}><RotateCcw size={15} /><span>Reset map</span></button>
    </div>
    <div className="sim-main">
      <div className="grid-zone">
        <div className="grid-heading"><span>THE ENVIRONMENT</span><span>10 columns × 7 rows</span></div>
        <div className="grid-with-axis">
          <div className="column-axis" aria-hidden="true">{Array.from({ length: COLS }, (_, i) => <span key={i}>{i}</span>)}</div>
          <div className="row-axis" aria-hidden="true">{Array.from({ length: ROWS }, (_, i) => <span key={i}>{i}</span>)}</div>
          <div className="world-grid" role="group" aria-label="Editable navigation grid. Use arrow keys to move between cells, and Enter or Space to edit.">
            {Array.from({ length: ROWS * COLS }, (_, id) => {
              const isWall = walls.has(id), isAgent = id === agent, isGoal = id === goal;
              const current = !searchDone && snapshot?.current === id;
              const state = isWall ? 'wall' : isAgent ? 'agent' : isGoal ? 'goal' : path.has(id) ? 'path' : current ? 'current' : frontier.has(id) ? 'frontier' : expanded.has(id) ? 'expanded' : 'empty';
              return <motion.button key={id} id={`grid-cell-${id}`} className={`grid-cell ${state} ${id === START ? 'start-cell' : ''}`} aria-label={`Row ${Math.floor(id / COLS)}, column ${id % COLS}: ${state}${id === START ? ', start' : ''}`} tabIndex={focused === id ? 0 : -1} onFocus={() => setFocused(id)} onKeyDown={(event) => handleKey(event, id)} onClick={() => editCell(id)} whileHover={reduced ? undefined : { scale: 1.06, zIndex: 2 }} whileTap={reduced ? undefined : { scale: .88 }}>
                {isAgent ? <motion.span layoutId="grid-agent" transition={{ type: 'spring', stiffness: 500, damping: 35 }} className="agent-marker"><Crosshair size={22} /></motion.span> : isGoal ? <Flag size={20} /> : isWall ? <span className="wall-pattern" /> : path.has(id) ? <span className="path-dot" /> : current ? <Crosshair size={17} /> : <span className="cell-point" />}
              </motion.button>;
            })}
          </div>
        </div>
        <div className="grid-legend"><span><i className="legend-agent" />Agent</span><span><i className="legend-goal" />Goal</span><span><i className="legend-wall" />Wall</span><span><i className="legend-checked" />Checked</span><span><i className="legend-frontier" />In queue</span><span><i className="legend-path" />Route</span></div>
        <p className="map-notice" role="status">{notice}</p>
      </div>
      <aside className="agent-monitor" aria-label="Agent monitor">
        <div className="monitor-top"><Crosshair size={15} /><span>AGENT MONITOR</span><span className="status-dot" /></div>
        <div className="monitor-phase"><span className="mono text-muted">CURRENT STATUS</span><h3>{phase}</h3></div>
        <dl className="monitor-data">
          <div><dt>Position</dt><dd>{position(agent)}</dd></div><div><dt>Goal</dt><dd>{position(goal)}</dd></div>
          <div><dt>Cells checked</dt><dd>{snapshot?.expanded.length || 0}<span> / {ROWS * COLS - walls.size}</span></dd></div>
          <div><dt>Moves made</dt><dd>{searchDone && result.found ? routeIndex : 0}</dd></div>
          <div><dt>Move cost</dt><dd>1</dd></div>
        </dl>
        <div className="monitor-message"><span className="mono text-muted">WHAT IS HAPPENING?</span><p aria-live="polite" aria-atomic="true">{explanation}</p></div>
        <div className="queue-preview"><span className="mono text-muted">NEXT IN QUEUE</span><div>{cursor > 0 && !searchDone && snapshot?.frontier.length ? snapshot.frontier.slice(0, 4).map((id) => <span key={id}>{position(id)}</span>) : <span className="queue-empty">{searchDone ? 'Search complete' : 'Waiting to start'}</span>}</div></div>
      </aside>
    </div>
    <div className="sim-controls">
      <div className="playback-buttons"><button className="button-primary" onClick={toggleRun}>{running ? <Pause size={16} /> : complete ? <RotateCcw size={16} /> : <Play size={16} />}{running ? 'Pause' : complete ? 'Run again' : 'Run agent'}</button><button className="button-secondary" onClick={nextStep}><StepForward size={17} />Step</button></div>
      <label className="speed-control">Speed<select aria-label="Speed" value={speed} onChange={(event) => setSpeed(event.target.value)}><option value="normal">Normal</option><option value="fast">Fast</option></select></label>
    </div>
    <div className="sim-footnote"><span className="small-label">SEARCH PREVIEW</span><p>This goal-based agent uses Breadth-First Search (BFS), introduced in Week 2. BFS checks nearby cells first. It finds the fewest moves here because all moves have the same cost.</p></div>
  </div>;
}
