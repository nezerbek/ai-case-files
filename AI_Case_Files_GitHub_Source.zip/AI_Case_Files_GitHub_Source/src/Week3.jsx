import { LocalSearchNotes } from './components/CourseNotes';
import { useMemo, useState } from 'react';
import { AnimatePresence, motion, MotionConfig } from 'framer-motion';
import { ArrowDown, ArrowRight, ArrowUpRight, BookOpen, Check, Compass, GitBranch, Mountain, RotateCcw, Route, Shuffle, Sparkles, Target, Waves } from 'lucide-react';
import CaseSelector from './components/CaseSelector';

const landscapes = {
  lecture: { label: 'Lecture example · Slide 38', values: [1, 3, 5, 8, 6, 4, 2] },
  practice: { label: 'Practice example · Task 3', values: [1, 4, 7, 5, 3, 6, 9, 8] },
};

function Heading({ number, title, label }) {
  return <div className="section-heading"><span className="section-number">{number}</span><h2>{title}</h2><span className="section-label mono">{label}</span></div>;
}

function LandscapeLab() {
  const [landscape, setLandscape] = useState('lecture');
  const [start, setStart] = useState(0);
  const [path, setPath] = useState([0]);
  const points = landscapes[landscape].values;
  const current = path[path.length - 1];
  const done = useMemo(() => {
    const neighbors = [current - 1, current + 1].filter((i) => i >= 0 && i < points.length);
    return neighbors.every((i) => points[i] <= points[current]);
  }, [current, landscape]);
  const step = () => {
    if (done) return;
    const neighbors = [current - 1, current + 1].filter((i) => i >= 0 && i < points.length);
    const best = neighbors.reduce((a, b) => points[a] >= points[b] ? a : b);
    setPath((old) => [...old, best]);
  };
  const reset = (index = start, nextLandscape = landscape) => { setStart(index); setPath([index]); setLandscape(nextLandscape); };
  const changeLandscape = (next) => { setLandscape(next); setStart(0); setPath([0]); };
  return <div className="w3-landscape-lab">
    <div className="w3-lab-head"><div><span className="eyebrow">{landscapes[landscape].label.toUpperCase()}</span><h3>Choose a starting position.</h3><p>Hill climbing checks the nearby values and moves to a better one. Select a start, then follow each step.</p></div><button className="w3-reset" onClick={() => reset()}><RotateCcw size={15} /> Reset</button></div>
    <div className="w3-landscape-tabs" role="tablist" aria-label="Choose a course example">{Object.entries(landscapes).map(([key, value]) => <button key={key} role="tab" aria-selected={landscape === key} className={landscape === key ? 'active' : ''} onClick={() => changeLandscape(key)}>{key === 'lecture' ? 'Lecture values' : 'Practice values'}</button>)}</div>
    <div className="w3-chart" aria-label={`Values: ${points.join(', ')}. Current position ${current}, value ${points[current]}`}>
      <div className="w3-chart-grid"><span>VALUE</span><i /><i /><i /><i /></div>
      <div className="w3-bars">{points.map((value, i) => <button key={i} className={`w3-bar ${path.includes(i) ? 'visited' : ''} ${i === current ? 'current' : ''} ${value === Math.max(...points) ? 'peak' : ''}`} style={{ '--bar-height': `${value * 8}%` }} onClick={() => reset(i)} aria-label={`Start at position ${i}, value ${value}`} aria-pressed={start === i}>
        <span className="w3-bar-value">{value}</span><i /><small>{i}</small>
      </button>)}</div>
      <div className="w3-chart-axis"><span>START POSITION</span><span>INDEX IN THE LECTURE LIST</span></div>
    </div>
    <div className="w3-lab-bottom"><div className="w3-lab-state"><span className="eyebrow">CURRENT STATE</span><strong>Position {current} <i>·</i> value {points[current]}</strong><small>{done ? 'No neighbor has a higher value. The search stops here.' : `Better neighbor: position ${points[current - 1] > points[current] ? current - 1 : current + 1}.`}</small></div><div className="w3-lab-actions"><div className="w3-visited" aria-label="Visited positions">{path.map((position, i) => <span key={`${position}-${i}`}>{position}{i < path.length - 1 && <ArrowRight size={12} />}</span>)}</div><button className="w3-step-button" onClick={step} disabled={done}>{done ? 'Search stopped' : 'Take next step'}{!done && <ArrowRight size={16} />}</button></div></div>
    <p className="w3-lab-caption">In the lecture example, every start reaches the highest point at position 3. In the practical example, starting at position 0 stops at a local maximum (7) at position 2, while the highest value is 9 at position 6.</p>
  </div>;
}

function LocalTraps() {
  return <div className="w3-traps-grid">
    <article className="w3-trap-card"><div className="w3-trap-icon"><Mountain size={20} /></div><span className="eyebrow">LOCAL MAXIMUM</span><h3>A nearby peak can stop the search.</h3><p>Hill climbing checks its neighbors. It can stop at a peak even when a higher peak exists somewhere else.</p><div className="w3-mini-peaks" aria-label="A lower local peak and a higher global peak"><i /><i /><i /><i /><i /><i /><i /><i /></div><small>LOCAL PEAK <span /> GLOBAL PEAK</small></article>
    <article className="w3-trap-card"><div className="w3-trap-icon"><Waves size={20} /></div><span className="eyebrow">PLATEAU & RIDGE</span><h3>The best direction may be unclear.</h3><p>On a plateau, many neighbors have the same value. On a ridge, improvement may need a sequence that one simple move cannot show.</p><div className="w3-landscape-terms"><span>PLATEAU <b>same value</b></span><span>RIDGE <b>hard direction</b></span></div></article>
    <article className="w3-trap-card w3-restart-card"><div className="w3-trap-icon"><RotateCcw size={20} /></div><span className="eyebrow">RANDOM RESTART</span><h3>Try more than one start.</h3><p>Run hill climbing from several starting states, then keep the best result. This takes more work but depends less on one unlucky start.</p><div className="w3-restart-flow"><span>START A</span><i /><span>START B</span><i /><span>START C</span><ArrowRight size={14} /><strong>KEEP BEST</strong></div></article>
  </div>;
}

const otherMethods = [
  { name: 'Simulated annealing', icon: Waves, label: 'SOMETIMES ACCEPT A WORSE MOVE', text: 'It explores neighbors like hill climbing, but may accept a worse move. A temperature controls this chance. As temperature falls, the search becomes more greedy.', formula: 'ΔE = next.value − current.value', detail: 'If ΔE > 0, accept the move. Otherwise, accept it with probability exp(ΔE / T).' },
  { name: 'Local beam search', icon: GitBranch, label: 'KEEP K CANDIDATES', text: 'Keep K current states. Generate their successors together and choose the best K for the next round. Candidates can share a promising region.', formula: 'K = 1 → one local search', detail: 'With more than one candidate, the searches interact through shared selection.' },
  { name: 'Genetic algorithms', icon: Shuffle, label: 'SEARCH WITH A POPULATION', text: 'Keep a population of candidate solutions. Select by fitness, combine candidates with crossover, and use mutation to add variation. Repeat across generations.', formula: 'Selection → crossover → mutation', detail: 'The new population starts the next generation.' },
];

export default function Week3() {
  return <MotionConfig reducedMotion="user">
    <a href="#brief" className="skip-link">Skip to the case</a>
    <div className="reading-progress reading-progress-static" aria-hidden="true" />
    <header className="masthead page-width">
      <a href="?case=01#top" className="wordmark" aria-label="AI Case Files, open the case index"><span className="brand-symbol"><GitBranch size={23} strokeWidth={1.6} /></span><span>AI CASE FILES<span className="wordmark-sub">A FIELD GUIDE TO THINKING MACHINES</span></span></a>
      <div className="masthead-right"><span>QAIRU</span><span className="masthead-divider" /><span>AI FUNDAMENTALS</span><a href="#sources" aria-label="View learning sources"><BookOpen size={18} /></a></div>
    </header>
    <CaseSelector week="03" />
    <main id="top" className="week3-page">
      <section className="hero page-width" aria-labelledby="case-title">
        <div className="hero-meta"><span className="eyebrow"><span className="tiny-square" />CASE FILE #03</span><span className="hero-topic">WEEK 03 · LOCAL SEARCH & OPTIMIZATION</span></div>
        <div className="hero-body"><div className="hero-copy">
          <motion.h1 id="case-title" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .45 }}>Improve the<br /><span>configuration<span className="title-period">.</span></span></motion.h1>
          <p className="hero-description">Some problems ask for a good complete solution, not a path to reach it. Local search starts with one candidate and tries to improve it.</p>
          <div className="hero-actions"><a href="#brief" className="read-link">Open the case <ArrowDown size={17} /></a><a href="#hill-climbing" className="hero-try">Try hill climbing <ArrowUpRight size={17} /></a></div>
        </div><div className="hero-visual week3-visual"><span className="cover-folio">03</span><div className="w3-cover"><div className="w3-cover-top"><span>LOCAL SEARCH</span><span>START → IMPROVE</span></div><div className="w3-cover-land"><i /><i /><i /><i /><i /><i /><i /></div><div className="w3-cover-foot"><span>CURRENT VALUE</span><strong>FIND A BETTER NEIGHBOR</strong></div></div><div className="visual-caption"><span className="caption-rule" /><span>CHANGE THE<br />SOLUTION.</span></div></div></div>
        <div className="hero-bottom"><div><Target size={15} /><span>KEEP A CANDIDATE</span><ArrowRight size={14} /><span>CHECK ITS NEIGHBORS</span><ArrowRight size={14} /><span>IMPROVE THE VALUE</span></div><span className="mono">WEEK 03 / LOCAL SEARCH</span></div>
      </section>

      <section id="brief" className="chapter-section page-width">
        <Heading number="01" title="A route is a complete solution" label="WHEN THE PATH IS NOT THE GOAL" />
        <div className="brief-layout"><div className="brief-text"><p className="lead-paragraph">In the course notes, a delivery route in Astana must visit several places. The solution is the full route. A small change can swap two stops, and the objective is to reduce the total route length.</p><p>Local search works on this kind of complete configuration. It keeps one or a few candidate solutions, checks nearby options, and tries to improve a measurable value.</p><p>The route is useful for understanding the task. The interactive lab below uses the lecture’s small list of numbers to show each hill-climbing step.</p></div>
          <div className="task-spec"><div className="task-spec-heading"><Route size={18} /><span>ASTANA DELIVERY ROUTE · COURSE NOTES</span></div><h3>Visit the listed stops.</h3><div className="spec-row"><span>State</span><strong>A complete route.</strong></div><div className="spec-row"><span>Neighbor</span><strong>Swap two stops.</strong></div><div className="spec-row"><span>Objective</span><strong>Reduce total route length.</strong></div><div className="spec-row"><span>Search style</span><strong>Improve a current solution.</strong></div></div></div>
        <div className="w3-concept-strip"><article><span className="eyebrow">STATE</span><h3>One full candidate.</h3><p>For a route problem, the state includes the whole visit order.</p></article><ArrowRight size={20} /><article><span className="eyebrow">NEIGHBOR</span><h3>A small change.</h3><p>Change one part, such as swapping two route stops.</p></article><ArrowRight size={20} /><article><span className="eyebrow">OBJECTIVE</span><h3>Choose what “better” means.</h3><p>Minimize route length or conflicts; maximize a value such as fitness.</p></article></div>
      </section>

      <section id="hill-climbing" className="chapter-section page-width">
        <Heading number="02" title="Move to a better neighbor" label="HILL CLIMBING" />
        <div className="w3-hill-intro"><div><p className="section-lead">Hill climbing starts at one state. It checks neighboring states and moves to a better one. It stops when no neighbor improves the value.</p><p className="w3-small-copy">This simple rule works well when local improvement is useful and cheap. Its result depends on the starting state and the shape of the landscape.</p></div><div className="w3-rule-card"><span className="eyebrow"><Compass size={14} /> CORE LOOP</span><div><span>CURRENT</span><ArrowRight size={15} /><span>NEIGHBORS</span><ArrowRight size={15} /><span>BEST</span><ArrowRight size={15} /><span>STOP OR MOVE</span></div></div></div>
        <LandscapeLab />
        <div className="w3-code-card"><div className="code-panel-head"><span className="eyebrow">PYTHON IDEA · LECTURE SLIDE 10</span><span className="code-slide-ref">CORE LOOP</span></div><pre><code>{`current = start\nwhile True:\n    neighbors = get_neighbors(current)\n    best = choose_best(neighbors)\n    if value(best) <= value(current):\n        return current\n    current = best`}</code></pre><p>The code looks at the current state, compares its neighbors, and stops when it cannot improve. The lecture’s concrete version uses list positions as states.</p></div>
      </section>

      <section id="escape" className="chapter-section page-width">
        <Heading number="03" title="Why can it stop too soon?" label="LOCAL SEARCH LIMITS" />
        <p className="section-lead">Hill climbing only sees nearby choices. A local maximum, a plateau or a ridge can make a good direction hard to find.</p>
        <LocalTraps />
        <div className="w3-queens-note"><div className="w3-queens-mark"><Sparkles size={23} /></div><div><span className="eyebrow">ANOTHER LECTURE EXAMPLE · N-QUEENS</span><h3>Turn a constraint into a value.</h3><p>For N-Queens, a state is a board with one queen in each column. A neighbor moves one queen. The value can count attacking queen pairs, so fewer conflicts is better and zero conflicts is the goal.</p></div><div className="w3-zero">0<span>CONFLICTS</span></div></div>
      </section>

      <section id="methods" className="chapter-section page-width">
        <Heading number="04" title="Use a strategy that can explore" label="MORE THAN GREEDY MOVES" />
        <p className="section-lead">Other methods keep more candidates or sometimes accept a worse step. They help explore different parts of the search space.</p>
        <div className="w3-methods">{otherMethods.map(({ name, icon: Icon, label, text, formula, detail }) => <article className="w3-method" key={name}><div className="w3-method-icon"><Icon size={20} /></div><span className="eyebrow">{label}</span><h3>{name}</h3><p>{text}</p><div className="w3-method-formula">{formula}</div><small>{detail}</small></article>)}</div>
        <div className="w3-continuous"><div><span className="eyebrow">CONTINUOUS OPTIMIZATION · SLIDES 32–35</span><h3>Some states are numbers, not discrete choices.</h3><p>In continuous optimization, a state can be a set of real-valued coordinates. Gradient descent moves opposite the gradient to reduce an objective. The lecture connects this idea to choosing locations for three airports.</p></div><div className="w3-gradient-equation"><span className="eyebrow">GRADIENT DESCENT</span><strong>x ← x − α ∇f(x)</strong><p>α is the step size. The gradient gives the direction of greatest increase.</p></div></div>
        <div className="w3-summary"><span className="eyebrow">THE MAIN IDEA</span><div><span>STATE</span><ArrowRight size={15} /><span>NEIGHBORS</span><ArrowRight size={15} /><span>EVALUATE</span><ArrowRight size={15} /><strong>IMPROVE</strong></div><p>Choose the problem representation first. If the final configuration matters more than the path, local search can be a good fit.</p></div>
      </section>
      <LocalSearchNotes />
      <section id="sources" className="sources-section page-width"><div><span className="eyebrow">LEARNING NOTES</span><h3>Built from Week 3.</h3></div><div><p><strong>Main sources:</strong> QAIRU AI Fundamentals, Week 3, <em>Local Search Algorithms</em>, and Practical 3. The lecture landscape and the local-maximum values come from the course materials.</p><p>The Astana route, N-Queens example, random restart and simulated annealing use the lecture or course practical. The chart compares the exact class examples.</p></div></section>
    </main>
    <footer className="footer page-width"><a href="?case=03#top" className="footer-brand">AI CASE FILES<span>03</span></a><span>QAIRU · AI FUNDAMENTALS · WEEK 03</span><a href="#top">Back to top <ArrowUpRight size={16} /></a></footer>
  </MotionConfig>;
}
