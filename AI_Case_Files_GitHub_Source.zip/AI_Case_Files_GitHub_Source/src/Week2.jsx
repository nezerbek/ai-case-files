import { SearchNotes } from './components/CourseNotes';
import { useState } from 'react';
import { AnimatePresence, motion, MotionConfig } from 'framer-motion';
import { ArrowDown, ArrowRight, ArrowUpRight, BookOpen, Check, ChevronRight, Compass, Flag, GitBranch, Layers, Route, Scale, Search, ShieldCheck, Target, TimerReset } from 'lucide-react';
import CaseSelector from './components/CaseSelector';

const strategies = {
  BFS: {
    name: 'Breadth-First Search',
    rule: 'Choose the shallowest frontier node.',
    structure: 'FIFO queue · first in, first out',
    note: 'BFS finds a path with the fewest actions when every action has the same cost. If actions have different costs, a shallow path may cost more.',
    metric: 'fewest actions',
  },
  DFS: {
    name: 'Depth-First Search',
    rule: 'Choose a deepest frontier node.',
    structure: 'LIFO stack · last in, first out',
    note: 'DFS follows one branch deeply, then goes back when it reaches a dead end. It can use less memory in many tree searches, but it may return a longer path.',
    metric: 'deepest branch',
  },
  UCS: {
    name: 'Uniform-Cost Search',
    rule: 'Choose the node with the lowest g(n).',
    structure: 'Priority queue · lowest cost first',
    note: 'g(n) is the exact cost from the start to node n. UCS compares total costs, so it can find a cheaper path when roads have different distances.',
    metric: 'lowest cost so far',
  },
  'A*': {
    name: 'A* Search',
    rule: 'Choose the node with the lowest f(n).',
    structure: 'Priority queue · lowest estimated total cost',
    note: 'A* adds the cost already paid to an estimate of the cost still to come. The estimate is a heuristic, written as h(n).',
    metric: 'lowest g(n) + h(n)',
  },
};

const bfsCode = `from collections import deque

def bfs(graph, start, goal):
    queue = deque([(start, [start])])

    while queue:
        state, path = queue.popleft()
        print("Exploring:", state)

        if state == goal:
            return path

        for next_state in graph[state]:
            queue.append(
                (next_state, path + [next_state])
            )

    return None

result = bfs(graph, "A", "G")
print("Solution:", result)`;
const dfsCode = `def dfs(graph, start, goal):
    stack = [(start, [start])]
    visited = set()

    while stack:
        state, path = stack.pop()
        print("Exploring:", state)

        if state == goal:
            return path

        if state not in visited:
            visited.add(state)
            for next_state in graph[state]:
                if next_state not in visited:
                    stack.append(
                        (next_state, path + [next_state])
                    )

    return None`;
const ucsCode = `def ucs(graph, start, goal):
    pq = [(0, start, [start])]
    best = {start: 0}

    while pq:
        cost, node, path = heapq.heappop(pq)
        if node == goal:
            return cost, path

        for nxt, step in graph[node]:
            new_cost = cost + step
            if new_cost < best.get(nxt, float('inf')):
                best[nxt] = new_cost
                heapq.heappush(
                    pq, (new_cost, nxt, path + [nxt])
                )

    return None`;

const astarCode = `import heapq

def astar(graph, start, goal, h):
    frontier = [(h[start], 0, start, [start])]
    best_g = {start: 0}
    expanded = []

    while frontier:
        f, g, node, path = heapq.heappop(frontier)
        if g != best_g.get(node):
            continue
        expanded.append(node)
        if node == goal:
            return path, g, expanded

        for neighbour, step_cost in graph[node]:
            new_g = g + step_cost
            if new_g < best_g.get(neighbour, float("inf")):
                best_g[neighbour] = new_g
                new_f = new_g + h[neighbour]
                heapq.heappush(
                    frontier,
                    (new_f, new_g, neighbour, path + [neighbour])
                )

    return None, float("inf"), expanded`;

function Heading({ number, title, label }) {
  return <div className="section-heading"><span className="section-number">{number}</span><h2>{title}</h2><span className="section-label mono">{label}</span></div>;
}

function StrategyLab() {
  const [algorithm, setAlgorithm] = useState('BFS');
  const active = strategies[algorithm];
  const astarRows = [['A', '2', '10', '12'], ['B', '5', '4', '9'], ['C', '7', '3', '10']];
  return <div className="search-strategy-lab">
    <div className="strategy-tabs" role="tablist" aria-label="Search strategies">
      {Object.keys(strategies).map((name) => <button key={name} role="tab" aria-selected={algorithm === name} className={algorithm === name ? 'strategy-tab active' : 'strategy-tab'} onClick={() => setAlgorithm(name)}>{name}<ChevronRight size={15} /></button>)}
    </div>
    <AnimatePresence mode="wait">
      <motion.div key={algorithm} className="strategy-panel" role="tabpanel" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: .18 }}>
        <div className="strategy-copy"><span className="eyebrow">{active.name.toUpperCase()}</span><h3>{active.rule}</h3><p>{active.note}</p><div className="strategy-meta"><span>FRONTIER RULE</span><strong>{active.structure}</strong></div></div>
        {algorithm === 'A*' ? <div className="astar-table-wrap"><div className="search-data-title"><span>LECTURE EXAMPLE · SLIDE 39</span><span>f(n) = g(n) + h(n)</span></div><table className="astar-table"><thead><tr><th>Node</th><th>g(n)</th><th>h(n)</th><th>f(n)</th></tr></thead><tbody>{astarRows.map((row) => <tr key={row[0]} className={row[0] === 'B' ? 'chosen' : ''}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>)}</tbody></table><p className="data-result"><Check size={16} /> A* chooses B because its f(n) is 9, the lowest value.</p></div>
          : <div className="frontier-visual"><span className="search-data-title">WHAT IT CHOOSES FIRST</span><div className="frontier-pick"><span className="frontier-symbol">{algorithm === 'BFS' ? '01' : algorithm === 'DFS' ? 'DEEP' : 'g'}</span><div><strong>{active.metric}</strong><small>{algorithm === 'BFS' ? 'Explore every node at this depth before going deeper.' : algorithm === 'DFS' ? 'Follow a branch, then return at a dead end.' : 'Compare the full cost from START to each node.'}</small></div></div><div className="frontier-line"><span>START</span><i /><span>FRONTIER</span><i /><span>NEXT</span></div></div>}
      </motion.div>
    </AnimatePresence>
  </div>;
}

function RouteCostExample() {
  return <div className="route-cost-panel">
    <div className="cost-graph" aria-label="Two routes: A to B costs 2 and B to F costs 10; A to C costs 8 and C to F costs 1">
      <div className="cost-node start">A<span>START</span></div>
      <div className="cost-branch"><div className="cost-edge dear"><i /><span>2</span></div><div className="cost-edge cheap"><i /><span>8</span></div></div>
      <div className="cost-middle"><div className="cost-node">B</div><div className="cost-node">C</div></div>
      <div className="cost-branch second"><div className="cost-edge dear"><i /><span>10</span></div><div className="cost-edge cheap"><i /><span>1</span></div></div>
      <div className="cost-node goal">F<span>GOAL</span></div>
    </div>
    <div className="cost-results"><div><span>ROUTE A → B → F</span><strong>2 + 10 = 12</strong></div><div className="least-cost"><span>ROUTE A → C → F</span><strong>8 + 1 = 9</strong><small>UCS selects this lower-cost path.</small></div></div>
    <p className="cost-caption">The lecture uses this example to show why BFS and UCS answer different questions. Both routes use two actions, but their total costs are different.</p>
  </div>;
}

function CodeShowcase() {
  const [algorithm, setAlgorithm] = useState('BFS');
  const code = { BFS: bfsCode, DFS: dfsCode, UCS: ucsCode, 'A*': astarCode }[algorithm];
  const note = {
    BFS: 'BFS puts new paths at the end of a queue and checks the oldest path first.',
    DFS: 'DFS uses a stack. The visited set helps it avoid exploring the same state again.',
    UCS: 'UCS uses a priority queue. It adds each road cost and keeps a better cost when it finds one.',
    'A*': 'A* adds the cost so far g(n) to the heuristic h(n). This practical code follows the Week 2 route exercise.',
  }[algorithm];
  const slide = { BFS: '17', DFS: '21', UCS: '27', 'A*': 'PRACTICE 2 · 8.1' }[algorithm];
  const tabNames = ['BFS', 'DFS', 'UCS', 'A*'];
  return <div className="code-showcase"><div className="code-intro"><span className="eyebrow">PYTHON MINI-LAB · COURSE CODE</span><h3>Compare the code.</h3><p>{note}</p><div className="code-notes"><div><Check size={15} /><span>{algorithm === 'BFS' ? <><code>deque</code> makes a queue.</> : algorithm === 'DFS' ? <><code>stack.pop()</code> takes the last item.</> : algorithm === 'UCS' ? <><code>heapq.heappop()</code> removes the smallest cost.</> : <><code>new_g + h[neighbour]</code> makes f(n).</>}</span></div><div><Check size={15} /><span>{algorithm === 'BFS' ? <><code>popleft()</code> takes the oldest plan.</> : algorithm === 'DFS' ? <><code>visited</code> stores explored states.</> : algorithm === 'UCS' ? <><code>cost + step</code> adds the road cost.</> : <><code>best_g</code> stores the best cost found.</>}</span></div><div><Check size={15} /><span>{algorithm === 'BFS' ? <><code>path + [next_state]</code> makes a new path.</> : algorithm === 'DFS' ? <>The stack follows a deep branch first.</> : algorithm === 'UCS' ? <>The priority is the total cost so far.</> : <>A* stops when it removes the goal from the priority queue.</>}</span></div></div></div><div className="week2-code-panel"><div className="code-panel-head"><div className="code-tabs">{tabNames.map((name) => <button key={name} className={algorithm === name ? 'code-tab active' : 'code-tab'} onClick={() => setAlgorithm(name)}>{name}</button>)}</div><span className="code-slide-ref">{algorithm === 'A*' ? slide : `WEEK 2 · SLIDE ${slide}`}</span></div><pre><code>{code}</code></pre></div></div>;
}

export default function Week2() {
  return <MotionConfig reducedMotion="user">
    <a href="#brief" className="skip-link">Skip to the case</a>
    <div className="reading-progress reading-progress-static" aria-hidden="true" />
    <header className="masthead page-width">
      <a href="?case=01#top" className="wordmark" aria-label="AI Case Files, open the case index"><span className="brand-symbol"><GitBranch size={23} strokeWidth={1.6} /></span><span>AI CASE FILES<span className="wordmark-sub">A FIELD GUIDE TO THINKING MACHINES</span></span></a>
      <div className="masthead-right"><span>QAIRU</span><span className="masthead-divider" /><span>AI FUNDAMENTALS</span><a href="#sources" aria-label="View learning sources"><BookOpen size={18} /></a></div>
    </header>
    <CaseSelector week="02" />
    <main id="top" className="week2-page">
      <section className="hero page-width" aria-labelledby="case-title">
        <div className="hero-meta"><span className="eyebrow"><span className="tiny-square" />CASE FILE #02</span><span className="hero-topic">WEEK 02 · UNINFORMED SEARCH, A* & HEURISTICS</span></div>
        <div className="hero-body"><div className="hero-copy">
          <motion.h1 id="case-title" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .45 }}>Search for<br /><span>the route<span className="title-period">.</span></span></motion.h1>
          <p className="hero-description">A search agent compares possible routes from a start to a goal. See how BFS, DFS, UCS and A* choose what to explore next.</p>
          <div className="hero-actions"><a href="#brief" className="read-link">Open the case <ArrowDown size={17} /></a><a href="#strategies" className="hero-try">Compare search strategies <ArrowUpRight size={17} /></a></div>
        </div><div className="hero-visual week2-visual"><span className="cover-folio">02</span><div className="search-cover"><div className="search-cover-head"><span>SEARCH SPACE</span><span>START → GOAL</span></div><div className="search-route-diagram"><span className="route-point start-point">A</span><span className="route-line top-line"><i>2</i></span><span className="route-point">B</span><span className="route-line top-line"><i>10</i></span><span className="route-point goal-point">F</span><span className="route-line bottom-line"><i>8</i></span><span className="route-point">C</span><span className="route-line bottom-line selected-route"><i>1</i></span></div><div className="search-cover-foot"><span>LOWER PATH COST</span><strong>8 + 1 = 9</strong></div></div><div className="visual-caption"><span className="caption-rule" /><span>COMPARE.<br />THEN EXPLORE.</span></div></div></div>
        <div className="hero-bottom"><div><Target size={15} /><span>MODEL THE PROBLEM</span><ArrowRight size={14} /><span>CHOOSE A STRATEGY</span><ArrowRight size={14} /><span>COMPARE COST</span></div><span className="mono">WEEK 02 / SEARCH METHODS</span></div>
      </section>

      <section id="brief" className="chapter-section page-width">
        <Heading number="01" title="Start with a search problem" label="DEFINE BEFORE SEARCHING" />
        <div className="brief-layout"><div className="brief-text"><p className="lead-paragraph">In the lecture, the route task starts in Astana and asks if the current city is Almaty. Each state is a city. The available actions are the roads to nearby cities, and each road has a distance cost.</p><p>Before an agent searches, we describe the start, the goal and what can happen after each action. The agent then compares possible plans without needing to store every detail of the real world.</p><p>This case follows the lecture’s route examples. It focuses on how a search strategy chooses what to explore, and how path cost changes the answer.</p></div>
          <div className="task-spec"><div className="task-spec-heading"><Route size={18} /><span>THE ROUTE TASK</span></div><h3>Can we reach Almaty?</h3><div className="spec-row"><span>Start</span><strong>Astana</strong></div><div className="spec-row"><span>States</span><strong>Cities on the map.</strong></div><div className="spec-row"><span>Actions</span><strong>Travel to an adjacent city.</strong></div><div className="spec-row"><span>Cost</span><strong>Road distance.</strong></div><div className="spec-row"><span>Goal test</span><strong>Is the current city Almaty?</strong></div></div></div>
        <div className="search-model-row"><article><span className="eyebrow"><Layers size={14} /> STATE SPACE GRAPH</span><h3>Each state appears once.</h3><p>A state-space graph represents possible world states and the actions that connect them.</p></article><ArrowRight className="model-arrow" size={22} /><article><span className="eyebrow"><GitBranch size={14} /> SEARCH TREE</span><h3>Each node is a plan.</h3><p>A search tree shows “what if” plans from the start. Different paths can reach the same state.</p></article><ArrowRight className="model-arrow" size={22} /><article><span className="eyebrow"><Search size={14} /> FRONTIER</span><h3>Plans to explore next.</h3><p>The frontier, also called the fringe, holds partial plans. The strategy picks the next one.</p></article></div>
      </section>

      <section id="strategies" className="chapter-section page-width">
        <Heading number="02" title="Choose what to explore next" label="THE FRONTIER RULE MATTERS" />
        <p className="section-lead">The four methods use the same problem model. They differ in how they choose the next node from the frontier. Select a method to see its rule.</p>
        <StrategyLab />
        <div className="iterative-note"><span className="iterative-index">ID</span><div><span className="eyebrow">ANOTHER UNINFORMED METHOD · SLIDE 24</span><h3>Iterative Deepening Search</h3><p>Run depth-limited DFS with a limit of 1, then 2, then 3. It uses DFS-like memory and still checks for shallow solutions first. Some work repeats.</p></div><div className="depth-sequence"><span>1</span><i /><span>2</span><i /><span>3</span><i /><span>…</span></div></div>
        <div className="python-bridge"><div className="python-mark">Py</div><div><span className="eyebrow">PYTHON IDEA FROM THE LECTURE</span><p><code>queue.popleft()</code> removes the oldest item for BFS. <code>stack.pop()</code> removes the last item for DFS. That small change gives the search a different order.</p></div></div>
        <div className="greedy-contrast"><div><span className="eyebrow">CONCEPT CHECK · PRACTICE 2</span><h3>Greedy Best-First Search looks only at h(n).</h3><p>It chooses the state that appears closest to the goal, but ignores the cost already paid. A* compares both parts: <strong>f(n) = g(n) + h(n)</strong>. This explains why a promising-looking route may not be the cheapest one.</p></div><div className="greedy-formulas"><span>GREEDY <b>h(n)</b></span><ArrowRight size={16} /><span>A* <b>g(n) + h(n)</b></span></div></div>
      </section>

      <section id="lab" className="chapter-section page-width">
        <Heading number="03" title="Fewest actions or lowest cost?" label="BFS AND UCS" />
        <p className="section-lead">BFS counts actions. UCS adds their costs. In the lecture’s weighted example, both routes use two roads, but one route is cheaper.</p>
        <RouteCostExample />
        <CodeShowcase /><p className="course-note-source">These are course code excerpts. Define the graph before running BFS or DFS, and import heapq before running UCS. The interface displays Python as text; use Python or a notebook to execute it.</p>
      </section>

      <section id="heuristics" className="chapter-section page-width">
        <Heading number="04" title="Give A* a useful estimate" label="PAST COST + FUTURE ESTIMATE" />
        <div className="heuristic-layout"><div className="heuristic-copy"><p className="lead-paragraph">UCS asks how much cost has been paid so far. A* also estimates how much cost may remain before the goal.</p><p><strong>g(n)</strong> is the exact cost from the start to node n. <strong>h(n)</strong> is an estimate of the remaining cost. A* adds them to get <strong>f(n) = g(n) + h(n)</strong>.</p><p>A heuristic is admissible when it never estimates more than the true cost to a nearest goal. If h(n) = 0 for every node, A* works like UCS.</p></div><div className="heuristic-equation"><span className="eyebrow"><Compass size={14} /> A* PRIORITY</span><div><span>g(n)</span><i>+</i><span>h(n)</span><i>=</i><strong>f(n)</strong></div><p>Exact cost so far <ArrowRight size={14} /> estimated cost left <ArrowRight size={14} /> estimated total</p></div></div>
        <div className="heuristic-note"><ShieldCheck size={20} /><p>The lecture’s A* example chooses node B: g(B) = 5 and h(B) = 4, so f(B) = 9. An admissible heuristic keeps the optimality guarantee shown in the lecture. If h overestimates the cost, A* may lose this guarantee.</p></div>
        <div className="grid-moves"><div><span className="eyebrow"><Compass size={14} /> GRID NEIGHBORS · SLIDE 43</span><p>The lecture’s grid navigator makes four possible moves. A boundary and wall check decides which moves are legal.</p><code className="direction-code">directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]</code><div className="direction-labels"><span>(-1, 0) up</span><span>(1, 0) down</span><span>(0, -1) left</span><span>(0, 1) right</span></div></div><div className="grid-move-info"><strong>Remember the route.</strong><p>The <code>came_from</code> dictionary stores how each state was reached, so the program can rebuild the final path.</p></div></div>
        <div className="checklist-grid"><div><span>01</span><h3>Pop the lowest f</h3><p>Take the frontier item with the smallest estimated total cost.</p></div><div><span>02</span><h3>Check the goal</h3><p>Stop if the selected state passes the goal test.</p></div><div><span>03</span><h3>Try neighbors</h3><p>Generate possible next states and compute each new path cost.</p></div><div><span>04</span><h3>Update the frontier</h3><p>Keep a better route, calculate f = g + h, and add it for later.</p></div></div>
      </section>

      <section className="chapter-section page-width">
        <Heading number="05" title="Check what the search did" label="MEASURE THE WORK" />
        <p className="section-lead">A search can be compared by its answer and by how much work it does. The lecture asks us to measure search behavior, not just look at the final path.</p>
        <div className="evaluation-grid"><div><span className="eyebrow"><Flag size={14} /> SOLUTION</span><h3>Did it reach the goal?</h3><p>Check that the returned sequence starts at the start state and reaches a goal.</p></div><div><span className="eyebrow"><Scale size={14} /> PATH COST</span><h3>How much did the route cost?</h3><p>Add the costs of the actions. BFS is optimal when every action has equal cost; UCS compares cost.</p></div><div><span className="eyebrow"><TimerReset size={14} /> SEARCH BEHAVIOR</span><h3>How much did it explore?</h3><p>Count expanded states and track the frontier to compare the work done by each method.</p></div></div>
        <div className="workflow-strip"><span className="eyebrow">SEARCH WORKFLOW</span><div>{['MODEL', 'ADD START', 'EXPAND', 'TEST GOAL', 'COMPARE'].map((item, i) => <span key={item}>{i > 0 && <ArrowRight size={15} />}{item}</span>)}</div></div>
      </section>
      <SearchNotes />
      <section id="sources" className="sources-section page-width"><div><span className="eyebrow">LEARNING NOTES</span><h3>Built from Week 2.</h3></div><div><p><strong>Main sources:</strong> QAIRU AI Fundamentals, Week 2, <em>Uninformed Search, A* Search & Heuristics</em>, and Practical Work No. 2. The A* code follows the solved route exercise; Greedy Best-First Search is explained as a comparison, as the practical asks.</p><p>The cases teach the core learning outcomes, without copying every slide or adding a new search algorithm.</p></div></section>
    </main>
    <footer className="footer page-width"><a href="?case=01#top" className="footer-brand">AI CASE FILES<span>02</span></a><span>QAIRU · AI FUNDAMENTALS · WEEK 02</span><a href="#top">Back to top <ArrowUpRight size={16} /></a></footer>
  </MotionConfig>;
}
