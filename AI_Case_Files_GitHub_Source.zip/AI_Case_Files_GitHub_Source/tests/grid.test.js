import test from 'node:test';
import assert from 'node:assert/strict';
import { breadthFirstSearch, neighbors, START, GOAL, INITIAL_WALLS, COLS } from '../src/lib/grid.js';

test('empty grid returns a shortest route without diagonal moves', () => {
  const result = breadthFirstSearch(0, 8, new Set(), 3, 3);
  assert.equal(result.path.length - 1, 4);
  for (let i = 1; i < result.path.length; i++) {
    assert.ok(neighbors(result.path[i - 1], new Set(), 3, 3).includes(result.path[i]));
  }
});

test('sample route reaches the goal and avoids every wall', () => {
  const walls = new Set(INITIAL_WALLS);
  const result = breadthFirstSearch(START, GOAL, walls);
  assert.equal(result.found, true);
  assert.equal(result.path[0], START);
  assert.equal(result.path.at(-1), GOAL);
  for (let i = 0; i < result.path.length; i++) {
    assert.ok(!walls.has(result.path[i]));
    if (i > 0) assert.ok(neighbors(result.path[i - 1], walls).includes(result.path[i]));
  }
  const visited = result.snapshots.map((step) => step.current);
  assert.equal(new Set(visited).size, visited.length);
  assert.equal(result.snapshots.at(-1).current, GOAL);
});

test('enclosed start returns no path and exhausts its queue', () => {
  const result = breadthFirstSearch(0, 8, new Set([1, 3]), 3, 3);
  assert.equal(result.found, false);
  assert.deepEqual(result.path, []);
  assert.deepEqual(result.snapshots.at(-1).frontier, []);
});

test('moving the goal changes the path, and start at goal needs no moves', () => {
  assert.equal(breadthFirstSearch(0, 0, new Set(), 3, 3).path.length - 1, 0);
  assert.equal(breadthFirstSearch(0, 2, new Set(), 3, 3).path.length - 1, 2);
});

test('grid edges never wrap into the next row', () => {
  assert.ok(!neighbors(COLS - 1, new Set()).includes(COLS));
  assert.ok(!neighbors(COLS, new Set()).includes(COLS - 1));
});
